import React from 'react'

const Otp = () => {
  return (
    <div>Otp</div>
  )
}

export default Otp