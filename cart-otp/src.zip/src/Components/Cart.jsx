import React from 'react';
import { Typography } from '@mui/material';
import Navbar from './Navbar';

const Cart = ({ cart }) => {
    console.log("Cart component:", cart);

    //  const handleAddCart = (item) => {
    //     const newCart = [...cart, item];
    //     setCart(newCart);
    //     console.log("items in cart", cart)
    // }

    return (
        <div>
            <Navbar />
            <h2>Cart Items</h2>
            <ul>
                {cart && cart.length > 0 ? (
                    cart.map((item, index) => (
                        <li key={index}>{item.title}</li>
                    ))
                ) : (
                    <li>No items in the cart</li>
                )}
            </ul>
        </div>
    );
}

export default Cart;
